package com.geiv.chaos;

import geivcore.DefaultFactor;
import geivcore.KeyFactor;
import geivcore.KeyListener;
import geivcore.R;
import geivcore.UESI;
import geivcore.enginedata.obj.Obj;

import java.awt.Color;
import java.awt.event.KeyEvent;

import com.thrblock.util.RandomSet;

public class Barnsleyfern extends DefaultFactor implements KeyListener{
	UESI UES;
	Obj crtPoint;
	public Barnsleyfern(UESI UES,int times){
		this.UES = UES;
	
		crtPoint = UES.creatObj(UESI.BGIndex);
		crtPoint.addGLPoint("70DBDB",0,0);
		crtPoint.show();
		
		crtPoint.setCentralX(0);
		crtPoint.setCentralY(0);
		
		UES.setViewOffsetX(90);
		
		this.setKeyListener(this);
		UES.pushKeyBoardIO(this);
		for(int i = 0;i < times;i++){
			generateNew();
		}
	}
	@Override
	public void doKeyBord(KeyFactor whom, int keyCode, boolean ispressed) {
		if(ispressed){
			if(keyCode == KeyEvent.VK_SPACE){
				generateNew();				
			}else if(keyCode == KeyEvent.VK_A){
				for(int i = 0;i < 100;i++){
					generateNew();									
				}
			}else if(keyCode == KeyEvent.VK_B){
				for(int i = 0;i < 1000;i++){
					generateNew();									
				}
			}
		}
	}
	public void generateNew(){
		float nx,ny;
		float ox = crtPoint.getCentralX()/150f,oy = (600 - crtPoint.getCentralY())/60f;
		double code = 100.0 * RandomSet.getRandomFloatIn_1();
		if(code >= 0&&code <= 1){
			nx = 0;
		    ny = 0.00f * ox + 0.16f * oy;
		}
		else if(code > 1&& code <= 86){
			nx = 0.85f*ox + 0.04f*oy;
			ny = -0.04f*ox + 0.85f*oy + 1.6f;
		}
		else if(code > 86&& code <= 93){
			nx = 0.2f*ox - 0.26f*oy;
			ny = 0.23f*ox + 0.22f*oy + 1.6f;
		}
		else{
			nx = -0.15f*ox + 0.28f*oy;
			ny = 0.26f*ox + 0.24f*oy + 0.44f;
		}
		Obj newPoint = UES.creatObj(UESI.BGIndex);
		newPoint.addGLPoint("70DBDB",0,0);
		newPoint.setColor(Color.GREEN);
		newPoint.setCentralX(nx*150f);
		newPoint.setCentralY(600 - ny*60f);
		newPoint.show();
		
		crtPoint = newPoint;
	}
	public static void main(String[] args) {
		UESI ues = new R();
		new Barnsleyfern(ues,0);
	}
}
