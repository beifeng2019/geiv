package com.geiv.chaos;

import java.awt.event.KeyEvent;

import com.thrblock.util.RandomSet;

import geivcore.DefaultFactor;
import geivcore.KeyFactor;
import geivcore.KeyListener;
import geivcore.R;
import geivcore.UESI;
import geivcore.enginedata.obj.Obj;

public class Sierpinski extends DefaultFactor implements KeyListener{
	UESI UES;
	Obj[] basePoint;
	Obj crtPoint;
	public Sierpinski(UESI UES,int times){
		this.UES = UES;
		basePoint = new Obj[3];
		for(int i = 0;i < 3;i++){
			basePoint[i] = UES.creatObj(UESI.BGIndex);
			basePoint[i].addGLPoint("70DBDB",0,0);
			basePoint[i].show();
		}
		basePoint[0].setCentralX(400);
		basePoint[0].setCentralY(60);
		
		basePoint[1].setCentralX(60);
		basePoint[1].setCentralY(550);
		
		basePoint[2].setCentralX(740);
		basePoint[2].setCentralY(550);
		
		crtPoint = basePoint[0];
		
		this.setKeyListener(this);
		UES.pushKeyBoardIO(this);
		for(int i = 0;i < times;i++){
			generateNew();
		}
	}
	@Override
	public void doKeyBord(KeyFactor whom, int keyCode, boolean ispressed) {
		if(ispressed){
			if(keyCode == KeyEvent.VK_SPACE){
				generateNew();				
			}else if(keyCode == KeyEvent.VK_A){
				for(int i = 0;i < 100;i++){
					generateNew();									
				}
			}else if(keyCode == KeyEvent.VK_B){
				for(int i = 0;i < 1000;i++){
					generateNew();									
				}
			}
		}
	}
	public void generateNew(){
		Obj flagPoint = basePoint[RandomSet.getRandomNum(0, 2)];
		float nx = (flagPoint.getCentralX() + crtPoint.getCentralX())/2f;
		float ny = (flagPoint.getCentralY() + crtPoint.getCentralY())/2f;
		
		Obj newPoint = UES.creatObj(UESI.BGIndex);
		newPoint.addGLPoint("70DBDB",0,0);
		newPoint.setColor(RandomSet.getRandomColdColor());
		newPoint.setCentralX(nx);
		newPoint.setCentralY(ny);
		newPoint.show();
		
		crtPoint = newPoint;
	}
	public static void main(String[] args) {
		UESI ues = new R();
		new Sierpinski(ues,0);
	}
}
